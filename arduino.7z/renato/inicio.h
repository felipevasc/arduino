const char PAGINA_INICIO[] PROGMEM = R"=====(
<html style="width: 100%; height: 100%;">
  <head>
    <title>SmartShot</title>
  </head>
  <body style="width: 100%; height: 100%;">
    <div  style="width: 100%; flex-direction: column; height: 100%; display: flex; justify-content: center; align-items: center; position: relative;">
      [CONTEUDO]
    </div>
  </body>
</html>
)=====";
